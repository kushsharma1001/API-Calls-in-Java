package com.mock.project1.DemoMock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMockApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMockApplication.class, args);
	}

}
